Папку "Русификатор" кинуть в
SteamLibrary\steamapps\common\The Coffin of Andy and Leyley\www\languages
